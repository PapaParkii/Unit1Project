﻿using System.ComponentModel.DataAnnotations;

namespace UnitOneProject.Models
{
/*
 * Name: Parker Jensen
 */
    public class SumModel
    {
        //validation
        [Required(ErrorMessage = "Please Enter First Number.")]
        [Range(-999999, 999999, ErrorMessage =
            "First Number must be between -999999 and 999999")]

        public double? FirstNumber {  get; set; }

        //validation
        [Required(ErrorMessage = "Please Enter Second Number.")]
        [Range(-999999, 999999, ErrorMessage =
            "Second Number must be between -999999 and 999999")]

        public double? SecondNumber { get; set; }

        public double? CalculateSum() 
        {
            double? first_number = FirstNumber;
            double? second_number = SecondNumber;
            
            //calculate the sum
            double? sum =  first_number + second_number;
            return sum;
        }
    }
}
