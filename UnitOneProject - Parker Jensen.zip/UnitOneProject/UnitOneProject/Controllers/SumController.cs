﻿using Microsoft.AspNetCore.Mvc;
using UnitOneProject.Models;

namespace UnitOneProject.Controllers
{
 /*
 * Name: Parker Jensen
 */
    public class SumController : Controller
    {
        [HttpGet]
        public IActionResult Sum()
        {
            ViewBag.Sum = 0;
            //sum calculator page
            return View();
        }

        [HttpPost]
        public IActionResult Sum(SumModel model) 
        { 
            if (ModelState.IsValid)
            {
                ViewBag.Sum = model.CalculateSum();
            }
            else 
            { 
                ViewBag.Sum = 0; 
            }
            return View(model);
        }
    }
}
