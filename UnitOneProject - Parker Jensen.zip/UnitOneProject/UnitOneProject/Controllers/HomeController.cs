﻿using Microsoft.AspNetCore.Mvc;

namespace UnitOneProject.Controllers
{
/*
* Name: Parker Jensen
*/
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            //Index (home page)
            return View();
        }

        public IActionResult Page2()
        {
            //Page 2 (Another page)
            return View();
        }

    }
}
